export default function Privacy() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-semibold mb-4">Privacy Policy</h1>
      <p>We respect your privacy. This page will be updated with our full policy soon.</p>
    </main>
  );
}
