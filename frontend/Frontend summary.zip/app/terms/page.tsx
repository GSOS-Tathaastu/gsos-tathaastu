export default function Terms() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-semibold mb-4">Terms & Conditions</h1>
      <p>Our standard terms and conditions will be published here shortly.</p>
    </main>
  );
}
